$(".admin_filter").change(function() {
  window.location.href = $(this).val();
});
